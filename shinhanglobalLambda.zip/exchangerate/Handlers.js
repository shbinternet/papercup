'use strict';

/*==============================================================================
 * FILE NAME : Handlers.js
 * DISCRIPTION : 환율조회 Alexa handlers
 *------------------------------------------------------------------------------
 *------------------------------------------------------------------------------
 * DATE			AUTHOR	CONTENT    
 *------------------------------------------------------------------------------
 * 2017-09-25	고동환	최초작성
 *=============================================================================*/

//Common imports
const GlobalApiClient = require('../common/GlobalApiClient');
const CommonIntents = require('../commonhandlers/CommonIntents');
const CommonMessages = require('../commonhandlers/CommonMessages');
const CommonEvents = require('../commonhandlers/CommonEvents');
const CommonHandlers = require('../commonhandlers/CommonHandlers');
const Config = require('../common/Config');

// Internal imports
const Intents = require('./Intents');
const Events = require('./Events');
const Messages = require('./Messages');

/**
 * This is the handler for our custom getExchangeRateHandler intent.
 * Refer to the Intents.js file for documentation.
 */
const getExchangeRateHandler = function() {
    console.info("Starting getExchangeRateHandler()");
/*
    const accessToken = this.event.context.user.accessToken;

    // If we have not been provided with a consent token, this means that the user has not
    // authorized your skill to access this information. In this case, you should prompt them
    // that you don't have permissions to retrieve their address.
    if(!accessToken) {
        this.emit(":tellWithPermissionCard", CommonMessages.NOTIFY_MISSING_PERMISSIONS, PERMISSIONS);

        // Lets terminate early since we can't do anything else.
        console.log("User did not give us permissions to access their address.");
        console.info("Ending getExchangeRateHandler()");
        return;
    }
*/
    let globalData = Config.openApiConfig;        
    globalData.path = "/global_api/exchangerate";

    const globalApiClient = new GlobalApiClient(globalData);

    let globalApiRequest = globalApiClient.getGlobalApi();  
	globalApiRequest.then((globalApiResponse) => {
		switch(globalApiResponse.statusCode) {
			case 200:
				console.log("D.H.Koh globalApiResponse.reqData=" + JSON.stringify(globalApiResponse.reqData));
				
				/*
                const ADDRESS_MESSAGE = Messages.ADDRESS_AVAILABLE +
                `${address['addressLine1']}, ${address['stateOrRegion']}, ${address['postalCode']}`;

                this.emit(":tell", ADDRESS_MESSAGE);				
				*/
				this.emit(":tell", JSON.stringify(globalApiResponse.reqData));
				break;
			case 204:
                this.emit(":tellWithCard", CommonMessages.NO_DATA);
                break;
            case 403:
                this.emit(":tellWithPermissionCard", CommonMessages.NOTIFY_MISSING_PERMISSIONS, PERMISSIONS);
                break;
            default:
                this.emit(":ask", CommonMessages.LOCATION_FAILURE, CommonMessages.LOCATION_FAILURE);
		
		}		
	});

	globalApiRequest.catch((error) => {
        this.emit(":tell", CommonMessages.ERROR);
        console.error(error);
        console.info("Ending getAccountListHandler()");
    });
};

/* CommonHandlers.js 에 공통정의 개별정의시 아래 내용 이용 함수정의

const newSessionRequestHandler = function() {
    console.info("Starting newSessionRequestHandler()");

    if(this.event.request.type === CommonEvents.LAUNCH_REQUEST) {
        this.emit(CommonEvents.LAUNCH_REQUEST);
    } else if (this.event.request.type === "IntentRequest") {
        this.emit(this.event.request.intent.name);
    }

    console.info("Ending newSessionRequestHandler()");
};

const launchRequestHandler = function() {
    console.info("Starting launchRequestHandler()");
    this.emit(":ask", CommonMessages.WELCOME + CommonMessages.WHAT_DO_YOU_WANT, CommonMessages.WHAT_DO_YOU_WANT);
    console.info("Ending launchRequestHandler()");
};


const sessionEndedRequestHandler = function() {
    console.info("Starting sessionEndedRequestHandler()");
    this.emit(":tell", CommonMessages.GOODBYE);
    console.info("Ending sessionEndedRequestHandler()");
};

const unhandledRequestHandler = function() {
    console.info("Starting unhandledRequestHandler()");
    this.emit(":ask", CommonMessages.UNHANDLED, CommonMessages.UNHANDLED);
    console.info("Ending unhandledRequestHandler()");
};


const amazonHelpHandler = function() {
    console.info("Starting amazonHelpHandler()");
    this.emit(":ask", CommonMessages.HELP, CommonMessages.HELP);
    console.info("Ending amazonHelpHandler()");
};


const amazonCancelHandler = function() {
    console.info("Starting amazonCancelHandler()");
    this.emit(":tell", CommonMessages.GOODBYE);
    console.info("Ending amazonCancelHandler()");
};



const amazonStopHandler = function() {
    console.info("Starting amazonStopHandler()");
    this.emit(":ask", CommonMessages.STOP, CommonMessages.STOP);
    console.info("Ending amazonStopHandler()");
};

*/

const handlers = {};
// Add event handlers
handlers[CommonEvents.NEW_SESSION] = CommonHandlers.newSessionRequestHandler;
handlers[CommonEvents.LAUNCH_REQUEST] = CommonHandlers.launchRequestHandler;
handlers[CommonEvents.SESSION_ENDED] = CommonHandlers.sessionEndedRequestHandler;
handlers[CommonEvents.UNHANDLED] = CommonHandlers.unhandledRequestHandler;

// Add intent handlers
handlers[CommonIntents.AMAZON_CANCEL] = CommonHandlers.amazonCancelHandler;
handlers[CommonIntents.AMAZON_STOP] = CommonHandlers.amazonStopHandler;
handlers[CommonIntents.AMAZON_HELP] = CommonHandlers.amazonHelpHandler;

handlers[Intents.GET_EXCHANGERATE_DATE] = getExchangeRateHandler;

module.exports = handlers;