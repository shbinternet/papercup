'use strict';

/*==============================================================================
 * FILE NAME : GibUtil.js
 * DISCRIPTION : 공통 Util
 *------------------------------------------------------------------------------
 *------------------------------------------------------------------------------
 * DATE			AUTHOR	CONTENT    
 *------------------------------------------------------------------------------
 * 2017-09-25	고동환	최초작성
 *=============================================================================*/

let gibUtil = {
		
	    /**
	     * 송신데이터 정의
	     * @param replaceJsonData : 변환요청데이터
	     * @param labelStr : 라벨 String
	     */
		'setLabelData' : function(labelStr,replaceJsonData) {
		    console.info("Starting setLabelData()");
    
		    for(let i = 0; i < replaceJsonData.data.length;i++) {
		    	let item = replaceJsonData.data[i].item;
		    	let value = replaceJsonData.data[i].value;		    	

		    	labelStr.replace(eval("/${" + item + "}/g"), value);		    	
		    }
		    		    		   		    
		    return labelStr;
		},		
		
		
}

module.exports = gibUtil;