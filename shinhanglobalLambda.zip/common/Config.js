'use strict';

/*==============================================================================
 * FILE NAME : Config.js
 * DISCRIPTION : Alexa Lambda 관련 환경설정정의
 *------------------------------------------------------------------------------
 *------------------------------------------------------------------------------
 * DATE			AUTHOR	CONTENT    
 *------------------------------------------------------------------------------
 * 2017-09-25	고동환	최초작성
 *=============================================================================*/

var Config = {
    // TODO Add Application ID
    appId : '',
    // TODO Add an appropriate welcome message.
    welcome_message : '<WELCOME_MESSAGE>',

    // TODO API 송신데이터설정
    openApiConfig : {
    	"domain": "satst.shinhanglobal.com",
    	"path": "/global_api/account/list",
    	"accessToken": "e938950b724a4821a94d571a93517060edfdcb77d95042269cd60b11b66d7ba36498578a32414101a02d787445f69c16237ddeb0a98648e5a0d0882331bc79c6997e5adafc3348f690124ee7607632a1e7a5c791f9a54e618038effc8e8fd648",
    	"personKey": "3456",
    	"sndData": {}    	    	
    }
};

module.exports = Config;